package duoc.uc.QuickOrder.Controller;

public class PedidoController {

}
