package duoc.uc.QuickOrder.Controller;

public class PedidoRepository {

}
